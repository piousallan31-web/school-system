alert("App.js is connected");
async function login() {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });
  
  if (error) {
    alert("Error:  " + error.message);
    console.log(error);
  } else {
    alert("Login successful!");
    window.location.href = "dashboard.html";
  }
}